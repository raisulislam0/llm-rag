import os
import ollama
import chromadb
import json
import hashlib
import logging
from flask import Flask, render_template, request, Response

# Suppress ChromaDB logging
logging.getLogger('chromadb').setLevel(logging.ERROR)

app = Flask(__name__)

# Static documentation content
docs = [
    {
        "title": "Using 52VIKING MPOS",
        "content": "How to use the 52VIKING MPOS app to serve customers in a store. Step 1: Launch the app on your device. Step 2: Log in with your credentials. Step 3: Start processing customer transactions.",
        "url": "/docs/page1"
    },
    {
        "title": "Setting Up 52VIKING MPOS",
        "content": "How to activate and set up the 52VIKING MPOS app on Android devices. Step 1: Download the app from the store. Step 2: Configure server settings. Step 3: Test the setup with a sample transaction.",
        "url": "/docs/page2"
    },
    {
        "title": "FAQs About MPOS",
        "content": "Answers to common questions about the 52VIKING MPOS solution. Q: What devices are supported? A: Android devices running version 8.0 or higher. Q: How do I reset my password? A: Contact your administrator.",
        "url": "/docs/page3"
    }
]

# Cache functions
def get_cache_path():
    return os.path.join(os.getcwd(), "response_cache.json")

def load_cache():
    cache_path = get_cache_path()
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading cache: {e}")
    return {}

def save_cache(cache):
    cache_path = get_cache_path()
    try:
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error saving cache: {e}")

def get_cache_key(query, context):
    combined = (query + context).encode('utf-8')
    return hashlib.md5(combined).hexdigest()

# Text processing functions
def split_text(text, chunk_size=500, overlap=50):
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size - overlap):
        end_idx = min(i + chunk_size, len(words))
        chunk = " ".join(words[i:end_idx])
        chunks.append(chunk)
        if end_idx == len(words):
            break
    return chunks

def embed_text(text, model="all-minilm"):
    response = ollama.embed(model=model, input=text)
    return response["embeddings"][0]

# Build ChromaDB collection
def build_collection(documents, collection_name="docs"):
    db_path = os.path.join(os.getcwd(), "chroma_db")
    client = chromadb.PersistentClient(path=db_path)
    try:
        collection = client.get_collection(name=collection_name)
        if collection.count() > 0:
            print("Using existing database...")
            return collection
    except Exception:
        collection = client.create_collection(name=collection_name)
        print("Created new collection")
    
    print(f"Embedding {len(documents)} documents...")
    for i, doc in enumerate(documents):
        split_doc = split_text(doc["content"])
        for j, chunk in enumerate(split_doc):
            embedding = embed_text(chunk)
            unique_id = f"doc_{i}_chunk_{j}"
            collection.add(
                ids=[unique_id],
                embeddings=[embedding],
                documents=[chunk]
            )
    print("Embedding complete")
    return collection

# Initialize collection with static docs
collection = build_collection(docs)

# Function to stream LLM response
def get_llm_response_stream(query, collection, model_llm="llama3.2", model_embed="all-minilm"):
    response_cache = load_cache()
    if len(query.split()) < 2:
        yield "Query too short. Please provide more details."
        return
    query_embedding = embed_text(query, model=model_embed)
    results = collection.query(query_embeddings=[query_embedding], n_results=1)
    if not results['documents'] or not results['documents'][0]:
        yield "No relevant information found."
        return
    context = "\n\n".join([doc for sublist in results['documents'] for doc in sublist])
    cache_key = get_cache_key(query, context)
    if cache_key in response_cache:
        yield response_cache[cache_key]
        return
    prompt = f"You are an AI overview generator based on the following information: '{context}', tell everything you know about the {query}; however, DON'T assume anything based on your own knowledge."
    response_stream = ollama.generate(model=model_llm, prompt=prompt, stream=True)
    full_response = ""
    for chunk in response_stream:
        if "response" in chunk:
            chunk_text = chunk["response"]
            full_response += chunk_text
            yield chunk_text
    yield "[DONE]"  # Signal end of stream
    response_cache[cache_key] = full_response
    save_cache(response_cache)

# Flask routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/search')
def search():
    query = request.args.get('q', '')
    if not query:
        return render_template('search.html', query="", results=[], llm_response="Please enter a search query.")
    results = [doc for doc in docs if query.lower() in doc['title'].lower() or query.lower() in doc['content'].lower()]
    return render_template('search.html', query=query, results=results)

@app.route('/docs/<page>')
def doc_page(page):
    if page == 'page1':
        return render_template('doc1.html')
    elif page == 'page2':
        return render_template('doc2.html')
    elif page == 'page3':
        return render_template('doc3.html')
    else:
        return "Page not found", 404

# Route for streaming LLM response
@app.route('/llm_stream')
def llm_stream():
    query = request.args.get('q', '')
    def generate():
        for chunk in get_llm_response_stream(query, collection):
            if chunk == "[DONE]":
                yield "data: [DONE]\n\n"
            else:
                yield f"data: {chunk}\n\n"
    return Response(generate(), mimetype='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True)